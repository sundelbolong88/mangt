### Whats the latest Growtopia Port?

* Currently its: 17196

### How to use CID-Creator-v2?

* Visit https://console.cloud.google.com/ and click the emoji that in the middle of gift and question mark emoji on right corner.
* After your cloud shell terminal ready paste this: 
git clone https://github.com/CapciGithub/Growtopia-CID-Creator-v2 and press enter.
* Write cd Growtopia-CID-Creator-v2/ and press enter again.
* After that write those commands: chmod +x createid and hit enter then do ./createid to start creating accounts
* If you want to stop creating do CTRL+C and to download created accounts write this: cloudshell download acc.txt and click the download button. 
Alternative: You can go to editor and download the acc.txt
- **Note**: It just creates CID, doesn't skips the tutorial so they will be bot accounts. You can enter them If you want but, If you do you gotta finish the tutorial. If you use them as bots you can do what normal player does.

### How to use CID-Creator-v2? ( Video Tutorial )

* English Tutorials: https://youtu.be/ACwncz2DR5o
* Indonesian Tutorials: https://youtu.be/k2k3-5ohfoA

### How to get new IP and create more accounts when you got too many account created error?

![Step 1:](https://i.gyazo.com/73aa287321bc3dc5cbe9c99a2bc48da2.png)
![Step 2:](https://i.gyazo.com/73e111f8f42f44a6e6bc725ffa7cafcd.png)
![Step 3:](https://i.gyazo.com/8f3c56081b3acc4d8f8e58c1e57f91a2.png)
